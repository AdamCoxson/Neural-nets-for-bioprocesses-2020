import torch
l = torch.load('Data2/Optimised_Networks/Models/manual7 1_15_30_0.001_8.pt')

print(l)

